package com.example.keycloak.db;

import org.keycloak.component.ComponentModel;
import org.keycloak.models.*;
import org.keycloak.storage.adapter.AbstractUserAdapterFederatedStorage;

import java.util.HashSet;
import java.util.Set;

public class HardcodedUserAdapter extends AbstractUserAdapterFederatedStorage {

    private final String username;

    public HardcodedUserAdapter(KeycloakSession session,
                                RealmModel realm,
                                ComponentModel model,
                                String username) {
        super(session, realm, model);
        this.username = username;
        this.storageId = "f:" + model.getId() + ":" + username;
    }

    @Override
    public String getUsername() { return username; }

    @Override
    public boolean isEnabled() { return true; }

    @Override
    public Set<RoleModel> getRealmRoleMappings() {
        Set<RoleModel> roles = new HashSet<>();

        switch (username.toLowerCase()) {
            case "alice":
                addRoles(roles, "AML_VIEWER", "AML_MAKER");
                break;
            case "bob":
                addRoles(roles, "AML_APPROVER");
                break;
            case "charlie":
                addRoles(roles, "AML_VIEWER", "AML_MAKER", "AML_APPROVER");
                break;
            default:
                addRoles(roles, "AML_VIEWER");
                break;
        }

        return roles;
    }

    private void addRoles(Set<RoleModel> roles, String... roleNames) {
        for (String r : roleNames) {
            RoleModel role = realm.getRole(r);
            if (role == null) role = realm.addRole(r);
            roles.add(role);
        }
    }
}
