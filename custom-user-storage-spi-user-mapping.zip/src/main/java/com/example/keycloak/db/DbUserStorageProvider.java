package com.example.keycloak.db;

import org.keycloak.component.ComponentModel;
import org.keycloak.credential.CredentialInput;
import org.keycloak.credential.CredentialInputValidator;
import org.keycloak.models.*;
import org.keycloak.storage.UserStorageProvider;
import org.keycloak.storage.user.UserLookupProvider;
import org.keycloak.storage.user.UserQueryProvider;

import java.util.stream.Stream;

public class DbUserStorageProvider implements
        UserStorageProvider,
        UserLookupProvider,
        UserQueryProvider,
        CredentialInputValidator {

    private final KeycloakSession session;
    private final ComponentModel model;

    public DbUserStorageProvider(KeycloakSession session, ComponentModel model) {
        this.session = session;
        this.model = model;
    }

    @Override
    public void close() {}

    @Override
    public UserModel getUserByUsername(RealmModel realm, String username) {
        return new HardcodedUserAdapter(session, realm, model, username);
    }

    @Override public UserModel getUserById(RealmModel realm, String id) { return null; }
    @Override public UserModel getUserByEmail(RealmModel realm, String email) { return null; }

    @Override
    public boolean supportsCredentialType(String credentialType) {
        return CredentialModel.PASSWORD.equals(credentialType);
    }

    @Override
    public boolean isConfiguredFor(RealmModel realm, UserModel user, String credentialType) {
        return true;
    }

    @Override
    public boolean isValid(RealmModel realm, UserModel user, CredentialInput input) {
        return true;
    }

    @Override public int getUsersCount(RealmModel realm) { return 0; }
    @Override public Stream<UserModel> getUsersStream(RealmModel realm, int firstResult, int maxResults) { return Stream.empty(); }
    @Override public Stream<UserModel> searchForUserStream(RealmModel realm, String search, Integer firstResult, Integer maxResults) { return Stream.empty(); }
    @Override public Stream<UserModel> searchForUserStream(RealmModel realm, String search, Integer firstResult, Integer maxResults, boolean exact) { return Stream.empty(); }
    @Override public Stream<UserModel> getGroupMembersStream(RealmModel realm, GroupModel group, Integer firstResult, Integer maxResults) { return Stream.empty(); }
    @Override public Stream<UserModel> searchForUserByUserAttributeStream(RealmModel realm, String name, String value) { return Stream.empty(); }
}
